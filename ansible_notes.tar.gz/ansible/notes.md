LINUX:
----------
umask
Sticky bit

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

ANSIBLE:
----------
ansible-doc -l
ansible-doc -l | grep -i file
ansible-doc file
ansible-playbook pb2.yml --syntax-check
ansible-playbook pb2.yml
TAGS => always, never, randomstring
ansible all -m file -a "path=/ansible.new state=touch mode=0755"
ansible-playbook apache.yml --list-tasks
ansible-playbook apache.yml --list-tags
ansible-playbook apache_tags.yml --tag content
